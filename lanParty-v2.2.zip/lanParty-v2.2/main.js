



import { module } from '/js/sponsors.js';
// Update fotos
sponsor_foto_1.src = module['sponsor1'].img
sponsor_foto_2.src = module['sponsor2'].img
sponsor_foto_3.src = module['sponsor3'].img
sponsor_foto_4.src = module['sponsor4'].img

// Sponsor page
const closePopUpsButtons = document.querySelectorAll('[data-close-button]');
const pageOverlay = document.getElementById('page-overlay');
pageOverlay.addEventListener('click', () => {
  // pop up screen 1
  const popUps = document.querySelectorAll('.sponsor-popup.page-active');
  popUps.forEach(popUp => {
    ClosePopUp(popupInfo);
  })
  // pop up screen 2
  const popUps2 = document.querySelectorAll('.sponsor-popup.page-active');
  popUps2.forEach(popUp2 => {
    ClosePopUp(popupInfo2);
  })
  // pop up screen 3
  const popUps3 = document.querySelectorAll('.sponsor-popup.page-active');
  popUps3.forEach(popUp3 => {
    ClosePopUp(popupInfo3);
  })
   // pop up screen 4
   const popUps4 = document.querySelectorAll('.sponsor-popup.page-active');
   popUps4.forEach(popUp4 => {
     ClosePopUp(popupInfo4);
   })
})

// Close button events
closePopUpsButtons.forEach(button => {
  button.addEventListener('click', () => {
    // popup screen 1
    const popUp = button.closest('.sponsor-popup');
    ClosePopUp(popupInfo);
    // popup screen 2
    const popUp2 = button.closest('.sponsor-popup');
    ClosePopUp(popupInfo2);
    // popup screen 3
    const popUp3 = button.closest('.sponsor-popup');
    ClosePopUp(popupInfo3);
    // popup screen 4
    const popUp4 = button.closest('.sponsor-popup');
    ClosePopUp(popupInfo4);
  })
})

// Popup controller functions
function OpenPopUp(popupInfo, id) {
  if (popupInfo == null) return;

  popupInfo.childNodes[3].innerHTML = module['sponsor'.concat(id)].text
  popupInfo.childNodes[1].childNodes[1].innerHTML = module['sponsor'.concat(id)].name
  popupInfo.parentNode.parentNode.childNodes[1].childNodes[1].src = module['sponsor'.concat(id)].img

  popupInfo.classList.add('page-active');
  pageOverlay.classList.add('page-active');
}
function ClosePopUp(popupInfo) {
  if (popupInfo == null) return;
  popupInfo.classList.remove('page-active');
  pageOverlay.classList.remove('page-active');
}

// Popop open events
const openPopUpsButtons = document.querySelectorAll('[data-info-target]');
openPopUpsButtons.forEach(button => {
  const popUp = document.querySelector(button.dataset.popupInfoTarget);
  button.addEventListener('click', () => {
    OpenPopUp(popupInfo, 1);
  })
})
const openPopUpsButtons2 = document.querySelectorAll('[data-info2-target]');
openPopUpsButtons2.forEach(button => {
  const popUp2 = document.querySelector(button.dataset.popupInfo2Target);
  button.addEventListener('click', () => {
    OpenPopUp(popupInfo2, 2);
  })
})
const openPopUpsButtons3 = document.querySelectorAll('[data-info3-target]');
openPopUpsButtons3.forEach(button => {
  const popUp3 = document.querySelector(button.dataset.popupInfo3Target);
  button.addEventListener('click', () => {
    OpenPopUp(popupInfo3, 3);
  })
})
const openPopUpsButtons4 = document.querySelectorAll('[data-info4-target]');
openPopUpsButtons4.forEach(button => {
  const popUp4 = document.querySelector(button.dataset.popupInfo4Target);
  button.addEventListener('click', () => {
    OpenPopUp(popupInfo4, 4);
  })
})

