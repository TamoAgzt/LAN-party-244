let module = {}

module.sponsor1 = {
    id: 1,

    name: '1',
    text: 'txt 1',
    img: './img/Beyond.jpg'
}

module.sponsor2 = {
    id: 2,

    name: '2',
    text: 'txt  2',
    img: './img/Trust.png'
}

module.sponsor3 = {
    id: 3,
    
    name: '3',
    text: 'txt 3',
    img: './img/biss-white.png'
}

module.sponsor4 = {
    id: 4,

    name: '4',
    text: ' txt 4',
    img: './img/SNK.png'
}

export { module }
